package com.example.MRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
