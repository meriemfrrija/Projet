package com.example.MRM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(MrmApplication.class, args);
	}

}
